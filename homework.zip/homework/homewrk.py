#1)
numbers=[num for num in range(1500,2701) if num%7==0 and num%5==0]
print(numbers)

#2)
temp=5
c_f=temp*9/5+5
print(c_f)
f_c=temp-32*5//9
print(f_c)

#3)
from re import*
password=input("enter a password")
valid="[a-z{1}A-Z{1}0-9{1}(6,16)]"
if valid:
    print("valid")
else:
    print("not valid")                        #not got

#4)
s1=int(input("enter a side"))
s2=int(input("enter a side"))
s3=int(input("enter a side"))
if s1==s2==s3:
    print("equilateral triangle")
elif(s1!=s2!=s3):
    print("scalene triangle")
else:
    print("isosceles triangle")

#5)
sentence=input("is it raining")
if "no":
    print("enjoy your day")
else:
    if "yes":
        print(input("is it too windy"))
    else: 
        if "yes":
            print("it is too windy for an umbrella")
        elif "no":
            print("take an umbrella")                        #didnt get




    
    







    